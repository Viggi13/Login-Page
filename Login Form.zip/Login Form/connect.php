<?php
    $Name= $_POST['Name'];
    $uname= $_POST['uname'];
    $email= $_POST['email'];
    $pno= $_POST['pno'];
    $pass= $_POST['pass'];
    $cpass= $_POST['cpass'];
    $gender= $_POST['gender'];
    
    // Database Connection
    $conn = new mysqli('localhost','root','','test');
    if($conn->connect_error){
        die('connection Failed : '.$conn->connect_error);
    }else{
        $stmt= $conn->prepare("insert into registration(Name, uname, email, pno, pass, cpass, gender) values(?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssisss",$Name,$uname,$email,$pno,$pass,$cpass,$gender);
        $stmt->execute();
        echo "Registration Successfully....";
        $stmt->close();
        $conn->close();
    }
?>